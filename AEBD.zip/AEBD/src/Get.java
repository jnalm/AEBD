
public class Get implements Gets {
	
	
	
}
