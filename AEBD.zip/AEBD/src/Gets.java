
public interface Gets {

}
