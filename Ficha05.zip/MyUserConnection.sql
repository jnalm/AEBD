-- FICHA 5

-- exercicio 1a
CREATE ROLE role;
 
GRANT CREATE table, CREATE view, CREATE procedure, CREATE trigger
TO role;

GRANT role TO JoaoNA;

CREATE TABLE PATROCINADOR (
    ID_PATROCINADOR NUMBER(5),
    NOME VARCHAR(200) NOT NULL,
    MONTANTE NUMBER(5) NOT NULL,
    CONSTRAINT Patrocinador_PK PRIMARY KEY(ID_PATROCINADOR))
    TABLESPACE aebd_tables
    STORAGE (INITIAL 50K);

-- exercicio 1a

-- interface sql developer


